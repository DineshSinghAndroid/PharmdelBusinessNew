import 'package:logger/logger.dart';

Logger logger = Logger();
