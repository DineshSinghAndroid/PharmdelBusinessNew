import '../main.dart';

class PrintLog {
  static void printLog(dynamic log) {
    logger.i(log);
  }
}
