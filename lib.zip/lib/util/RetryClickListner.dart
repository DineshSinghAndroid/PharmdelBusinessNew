abstract class RetryClickListner {
  void onClickListner();
}
