// import 'package:sentry_flutter/sentry_flutter.dart';

class SentryExemption {
  static sentryExemption(e, stackTrace) async {
    // await Sentry.captureException(
    //   e,
    //   stackTrace: stackTrace,
    // );
  }
}
